# TEMPLATES

**This directory is required.**

The templates directory contains your jinja.j2 files.
