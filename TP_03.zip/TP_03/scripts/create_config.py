import json
from jinja2 import Template, Environment,  FileSystemLoader

env = Environment(loader=FileSystemLoader("templates"))


def load_json_data_from_file(file_path):
    try :  
        f = open(file_path) # Opening JSON file
        data = json.load(f) # returns JSON object as a dict
        print(data)
        return data
    except FileNotFoundError as e: 
        print("Fichier introuvable")  
    pass

def render_network_config(template_name, data):
    template = env.get_template(template_name)
    return template.render(data) 
    pass

def save_built_config(file_name, data):
    f = open(file_name, "w")
    f.write(data)
    f.close()
    pass


def create_config_cpe_lyon_batA():
    dataESW1 = load_json_data_from_file('data/ESW1_CPE_LYON_BAT_A.json')
    esw1_A  = render_network_config('vlan_switch.j2',dataESW1)

    dataR1 = load_json_data_from_file('data/R1_CPE_LYON_BAT_A.json')
    r1_A  = render_network_config('vlan_router.j2',dataR1)
    r1_A  = r1_A + render_network_config('vrrp_router.j2',dataR1)

    dataR2 = load_json_data_from_file('data/R2_CPE_LYON_BAT_A.json')
    r2_A  = render_network_config('vlan_router.j2',dataR2)
    r2_A  = r2_A + render_network_config('vrrp_router.j2',dataR2)

   
    return esw1_A, r1_A, r2_A
    pass


def create_config_cpe_lyon_batB():
    dataESW1 = load_json_data_from_file('data/ESW1_CPE_LYON_BAT_B.json')
    esw1_B  = render_network_config('vlan_switch.j2',dataESW1)

    dataR1 = load_json_data_from_file('data/R1_CPE_LYON_BAT_B.json')
    r1_B  = render_network_config('vlan_router.j2',dataR1)
    r1_B = r1_B + render_network_config('vrrp_router.j2',dataR1)


    dataR2 = load_json_data_from_file('data/R2_CPE_LYON_BAT_B.json')
    r2_B  = render_network_config('vlan_router.j2',dataR2)
    r2_B  = r2_B + render_network_config('vrrp_router.j2',dataR2)

   
    return esw1_B, r1_B, r2_B 
    
    pass

def create_ospf_config():

    dataR1_A = load_json_data_from_file('data/R1_CPE_LYON_BAT_A.json')
    configR1_A = render_network_config('ospf.j2',dataR1_A)

    dataR2_A = load_json_data_from_file('data/R2_CPE_LYON_BAT_A.json')
    configR2_A = render_network_config('ospf.j2',dataR2_A)

    dataR1_B = load_json_data_from_file('data/R1_CPE_LYON_BAT_B.json')
    configR1_B = render_network_config('ospf.j2',dataR1_B)

    dataR2_B = load_json_data_from_file('data/R2_CPE_LYON_BAT_B.json')
    configR2_B = render_network_config('ospf.j2',dataR2_B)




    return configR1_A, configR2_A, configR1_B, configR2_B, configR5, configR6


    pass
    
if __name__ == "__main__":
    """
        process question 3 to 5:
    """
    #question 3:
    esw1_A, r1_A, r2_A = create_config_cpe_lyon_batA()

    #question 4:
    save_built_config('config/R1_CPE_LYON_BAT_A.conf', r1_A)
    save_built_config('config/R2_CPE_LYON_BAT_A.conf', r2_A)
    save_built_config('config/ESW1_CPE_LYON_BAT_A.conf', esw1_A)

    #question 5:
    esw1_B, r1_B, r2_B = create_config_cpe_lyon_batB()
    save_built_config('config/R1_CPE_LYON_BAT_B.conf', r1_B)
    save_built_config('config/R2_CPE_LYON_BAT_B.conf', r2_B)
    save_built_config('config/ESW1_CPE_LYON_BAT_B.conf', esw1_B)

    OSPF_r1_A, OSPF_r2_A, OSPF_r1_B, OSPF_r2_B, OSPF_R5, OSPF_R6 = create_ospf_config()
    save_built_config('config/OSPF_R1A.conf', OSPF_r1_A)
    save_built_config('config/OSPF_R1B.conf', OSPF_r1_B)
    save_built_config('config/OSPF_R2B.conf', OSPF_r2_B)
    save_built_config('config/OSPF_R2A.conf', OSPF_r2_A)