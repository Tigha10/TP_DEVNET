from nornir import InitNornir
from nornir.core.task import Task, Result
from nornir_utils.plugins.functions import print_result
from nornir_napalm.plugins.tasks import napalm_get,napalm_configure, napalm_cli
from nornir_netmiko.tasks import netmiko_send_config,netmiko_send_command, netmiko_save_config, netmiko_commit

def hello_world(task: Task) -> Result:
        return Result(
        host=task.host,
        result=f"{task.host.name} says hello world!"
        ) 

def show_interface_status(task: Task) -> Result:
    command = "show ip int brief"
    result = task.run(task=napalm_cli, commands=[command])
    return Result(
        host=task.host,
        result=result[0].result,
    )

def show_arp_table(task: Task) -> Result:
    command = "arp_table"
    result = task.run(task=napalm_get, getters=[command])
    arp_table = result[0].result["arp_table"]
    return Result(
        host=task.host,
        result=f"arp table:\n{arp_table}\n"
    )


def save_running_config(task: Task) -> Result:
    result = task.run(task=napalm_cli, commands=["wr"])
    return result

def create_loopback_r1(task: Task) -> Result:
    configurationR1 = [
        "interface loopback 1",
        "ip address 1.1.1.1 255.255.255.255"
    ]
    result = task.run(task=napalm_configure, config_commands=configurationR1)
    return result


def create_loopback_r2(task: Task) -> Result:
    configurationR2 = [
        "interface loopback 1",
        "ip address 2.2.2.2 255.255.255.255"
    ]
    result = task.run(task=napalm_configure, config_commands=configurationR2)
    return result

def show_int_netmiko(task: Task) -> Result:
    result = task.run(task=netmiko_send_command, command_string="show ip int brief")
    return Result(
        host=task.host,
        result=result[0].result,
    )

def create_loopback2_R1(task: Task) -> Result:
    result = task.run(task=netmiko_send_config, config_commands=["interface loopback 2","ip address 1.1.1.2 255.255.255.255"])
    return result


def create_loopback2_R2(task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_commands=["interface loopback 2","ip address 2.2.2.3 255.255.255.255"])
    return result

def save_running_config_net(task: Task) -> Result:
    result = task.run(task=netmiko_save_config)
    return result

def create_conf_R1_A (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/R1_CPE_LYON_BAT_A.conf')
    return result

def create_conf_R2_A (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/R2_CPE_LYON_BAT_A.conf')
    return result

def create_conf_ESW1_A (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/ESW1_CPE_LYON_BAT_A.conf')
    return result

def create_conf_R1_B (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/R1_CPE_LYON_BAT_B.conf')
    return result

def create_conf_R2_B (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/R2_CPE_LYON_BAT_B.conf')
    return result

def create_conf_ESW1_B (task: Task) -> Result:
    
    result = task.run(task=netmiko_send_config, config_file='config/ESW1_CPE_LYON_BAT_B.conf')
    return result

def create_conf_ospf_R1_A (task: Task) -> Result:
    result = task.run(task=netmiko_send_config, config_file='config/OSPF_R1A.conf')
    return result

def create_conf_ospf_R2_A (task: Task) -> Result:
    result = task.run(task=netmiko_send_config, config_file='config/OSPF_R2A.conf')
    return result

def create_conf_ospf_R1_B (task: Task) -> Result:
    result = task.run(task=netmiko_send_config, config_file='config/OSPF_R1A.conf')
    return result

def create_conf_ospf_R2_B (task: Task) -> Result:
    result = task.run(task=netmiko_send_config, config_file='config/OSPF_R2B.conf')
    return result





def question_13(nr):
    print(nr.__dict__)
    pass

def question_14(nr):
    print(nr.inventory.hosts)
    pass

def question_15(nr):
    print(type(nr.inventory.hosts['R1-CPE-BAT-A']))
    pass

def question_16(nr):
    print(dir(nr.inventory.hosts['R1-CPE-BAT-A']))
    host = nr.inventory.hosts['R1-CPE-BAT-A']
    print("adresse IP :", {host.hostname})
    print("username :", {host.username})
    print("password :", {host.password})
    pass

def question_17(nr):
    print((nr.inventory.hosts['R1-CPE-BAT-A'].keys()))
    pass

def question_18(nr):
    print(nr.inventory.hosts['R1-CPE-BAT-A'].data['room'])
    pass

def question_19(nr):
    print(nr.inventory.groups)
    pass

def question_20(nr):
    print(nr.inventory.hosts.get('R1-CPE-BAT-A').groups)
    pass

def question_21(nr):
    print(nr.inventory.hosts.get('R1-CPE-BAT-A').groups[0].keys())
    pass

def question_22(nr):
    print(nr.inventory.hosts.get('R1-CPE-BAT-A').groups[0].data['vendor'])
    pass

def question_23(nr):
    for host, host_obj in nr.inventory.hosts.items():
        print(host_obj.hostname)
    pass

def question_24(nr):
    print(nr.filter(device_model="C7200").inventory.hosts.keys())
    pass

def question_25(nr):
    print(nr.filter(device_type="router_switch").inventory.hosts.keys())
    pass

def question_26(nr):
    result = nr.run(task=hello_world)
    print(result)
    pass

def question_27(nr):
    result = nr.run(task=hello_world)
    print(type(result))
    pass

def question_29(nr):
    print_result(nr.run(task=hello_world))
    pass

def question_30(nr):
    print_result(nr.filter(device_type='router_switch').run(task=hello_world))
    pass

def question_32(nr):
    resultat = nr.filter(device_type='router').run(task=show_interface_status)
    print_result(resultat)
    pass
 
def question_33(nr):
    resultat = nr.filter(device_type='router_switch').run(task=show_arp_table)
    print_result(resultat)
    pass

def question_34(nr):
    result_r1 = nr.filter(hostname="172.16.100.125").run(task=create_loopback_r1)
    print_result(result_r1)

    result_r2 = nr.filter(hostname="172.16.100.126").run(task=create_loopback_r2)
    print_result(result_r2)
    pass

def question_35(nr):
    result = nr.run(task=save_running_config)
    print_result(result)
    pass

def question_36(nr):
    resultat = nr.filter(device_type='router').run(task=show_int_netmiko)
    print_result(resultat)
    pass

def question_37(nr):
    result_R1_net = nr.filter(hostname="172.16.100.125").run(task=create_loopback2_R1)
    print_result(result_R1_net)

    result_R2_net = nr.filter(hostname="172.16.100.126").run(task=create_loopback2_R2)
    print_result(result_R2_net)
    pass

def question_38(nr):
    result = nr.run(task=save_running_config_net)
    print_result(result)
    pass

def question_39(nr):

    result_R1_A_net = nr.filter(hostname="172.16.100.125").run(task=create_conf_R1_A)
    print_result(result_R1_A_net)

    result_R2_A_net = nr.filter(hostname="172.16.100.126").run(task=create_conf_R2_A)
    print_result(result_R2_A_net)

    result_ESW1_A_net = nr.filter(hostname="172.16.100.123").run(task=create_conf_ESW1_A)
    print_result(result_ESW1_A_net)


    result_R1_B_net = nr.filter(hostname="172.16.100.189").run(task=create_conf_R1_B)
    print_result(result_R1_B_net)

    result_R2_B_net = nr.filter(hostname="172.16.100.190").run(task=create_conf_R2_B)
    print_result(result_R2_B_net)

    result_ESW1_B_net = nr.filter(hostname="172.16.100.187").run(task=create_conf_ESW1_B)
    print_result(result_ESW1_B_net)
    pass

def question_39_d(nr):
    pass

def question_40(nr):

    result_R1_A_net = nr.filter(hostname="172.16.100.125").run(task=create_conf_ospf_R1_A)
    print_result(result_R1_A_net)

    result_R2_A_net = nr.filter(hostname="172.16.100.126").run(task=create_conf_ospf_R2_A)
    print_result(result_R2_A_net)
    
    result_R1_B_net = nr.filter(hostname="172.16.100.189").run(task=create_conf_ospf_R1_B)
    print_result(result_R1_B_net)

    result_R2_B_net = nr.filter(hostname="172.16.100.190").run(task=create_conf_ospf_R2_B)
    print_result(result_R2_B_net)



    pass
    

if __name__ == "__main__":
    nr = InitNornir(config_file="inventory/config.yaml")

    # question_13(nr)
    # question_14(nr)
    # question_15(nr)
    # question_16(nr)
    # question_17(nr)
    # question_18(nr)
    # question_19(nr)
    # question_20(nr)
    # question_21(nr)
    # question_22(nr)
    # question_23(nr)
    # question_24(nr)
    # question_25(nr)
    # question_26(nr)
    # question_27(nr)
    # question_29(nr)
    # question_30(nr)

    # question_32(nr)
    # question_33(nr)
    # question_34(nr)
    # question_35(nr)
    # question_36(nr)
    # question_37(nr)
    # question_38(nr)
    # question_39(nr)
    # question_39_d(nr)

    question_40(nr)
    pass
