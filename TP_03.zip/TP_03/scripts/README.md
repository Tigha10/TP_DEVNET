# SCRIPTS

**This directory is required.**

The scripts directory contains your python scripts.
