export FLASK_APP=fastprod/api
export FLASK_DEBUG=1
flask run