
from utils.inventory import add_item_to_hosts_yaml


def get_inventory():
    from api import app
    hosts = app.config.get('nr').inventory.dict().get('hosts').keys()
    return list(map(lambda item: app.config.get('nr').inventory.dict().get('hosts').get(item),hosts))

def add_device(device):
    from api import app
    device = add_item_to_hosts_yaml(item=device)
    return device