# INVENTORY

**This directory is required.**

The inventory directory contains your JSON or YAML files to store your cisco devices.
