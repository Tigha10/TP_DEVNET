# DATA

**This directory is required.**

The data directory contains your JSON or YAML files.
