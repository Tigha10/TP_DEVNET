import json
from napalm import get_network_driver


def get_inventory():
    pass


def get_json_data_from_file(file):
    pass

def question_26(device):
    pass


def question_27(device):
    pass


def question_28(device):
    pass

def question_29(device):
    pass


def question_30(device):
    pass


def question_31():
    pass


def question_32():
    pass


def question_34():
    pass



if __name__ == "__main__":
    r01 = {
        'hostname':'xx.xx.xx.xx',
        'username': "xx",
        'password': "xx"
    }

    # driver = get_network_driver('ios')
    # device  = driver(**r01)
    # device.open()
    
    #question_26(device)
    #question_27(device)
    #question_28(device)
    #question_29(device)
    #question_30(device)
    #question_31()
    #question_32()
    #question_34()