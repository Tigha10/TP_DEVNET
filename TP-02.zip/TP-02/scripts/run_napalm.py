import json
from napalm import get_network_driver


def get_inventory():
    pass


def get_json_data_from_file(file):
    pass

def question_26(device):
    command= ["show ip int brief"]
    output = device.cli(command)
    print(output)
    pass


def question_27(device):
    command= ["show ip int brief"]
    output = device.cli(command)
    print(type(output))
    print(output.keys())
    pass


def question_28(device):
    output = device.get_arp_table()
    print(output)
    pass

def question_29(device):
    output = device.get_arp_table()
    print(type(output))
    pass


def question_30(device):
    output = device.load_merge_candidate(filename='config/loopback_R01.conf')
    print(device.compare_config())
    device.commit_config()
    pass


def question_31():
    pass


def question_32():
    try :  
        f = open("inventory/hosts.json") # Opening JSON file
        data = json.load(f) # returns JSON object as a dict
        for device in data : 
            if device['hostname'] == "R01" or device['hostname'] == "R02" or device['hostname'] == "R03":
                print(device)
                name = {
                        'hostname': device.get("ip"),
                        'username': device.get("username"),
                        'password': device.get("password")
                    }

                driver = get_network_driver('ios')
                d = driver(**name)
                d.open()
                cfg_file = "config/ospf_{0}.conf".format(device.get("hostname"))
                output = d.load_merge_candidate(filename=cfg_file)
                print(d.compare_config())
                d.commit_config()
                
    
    except FileNotFoundError as e: 
        print("Fichier introuvable") 
    pass
    


def question_34():
    try :  
        f = open("inventory/hosts.json") # Opening JSON file
        data = json.load(f) # returns JSON object as a dict
        for device in data : 
                    host = device['hostname']
                    name = {
                            'hostname': device.get("ip"),
                            'username': device.get("username"),
                            'password': device.get("password")
                        }

                    driver = get_network_driver('ios')
                    d = driver(**name)
                    d.open()
                    command= ["show run"]
                    output = d.cli(command)
                    print(output)
                    output_cfg = output.get("show run")
                    f = open(host +".bak", "w")
                    f.write(output_cfg)
                    f.close()
    except FileNotFoundError as e: 
        print("Fichier introuvable")
    pass



if __name__ == "__main__":
    r01 = {
        'hostname':   '172.16.100.62',
        'username': 'cisco',
        'password': 'cisco'
    }

    driver = get_network_driver('ios')
    device  = driver(**r01)
    device.open()
    
    #question_26(device)
    #question_27(device)
    #question_28(device)
    #question_29(device)
    #question_30(device)
    #question_31()
    #question_32()
    question_34()